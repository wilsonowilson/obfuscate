import{s as e}from"./storage-1f8884de.js";chrome.runtime.onInstalled.addListener(()=>{e.get().then(console.log)});
