const e={count:0},s={get:()=>chrome.storage.sync.get(e),set:t=>chrome.storage.sync.set(t)};export{s};
